# TypeScript1
Part1 de Estudos de TypeScript
